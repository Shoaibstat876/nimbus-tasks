PS D:\Shoaib Project\nimbus-tasks> @'
>> {"email":"user1@test.com","password":"Pass12345!"}
>> '@ | Set-Content -Encoding utf8 login.json
>> 
PS D:\Shoaib Project\nimbus-tasks> curl.exe -s -X POST "http://127.0.0.1:8000/api/auth/register" -H "Content-Type: application/json" --data-binary "@login.json"
>> 
{"ok":true,"id":16,"email":"user1@test.com"}
PS D:\Shoaib Project\nimbus-tasks> curl.exe -s -X POST "http://127.0.0.1:8000/api/auth/login/json" -H "Content-Type: application/json" --data-binary "@login.json"
>> 
{"access_token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNiIsImlhdCI6MTc2ODQxMzM1NSwiZXhwIjoxNzY4NDk5NzU1fQ.ZOHyt2sX15vu-jBri_hMzphbnhQ8xwiUJDjUAGlrZ6U","token_type":"bearer"}
PS D:\Shoaib Project\nimbus-tasks> @'
>> {"message":"hello"}
>> '@ | Set-Content -Encoding utf8 chat.json
>> 
PS D:\Shoaib Project\nimbus-tasks> curl.exe -s -X POST "http://127.0.0.1:8000/api/chat" -H "Authorization: Bearer TOKEN_A" -H "Content-Type: application/json" --data-binary "@chat.json"
>> 
{"detail":"Invalid token"}
PS D:\Shoaib Project\nimbus-tasks> curl.exe -i -H "Authorization: Bearer TOKEN_A" "http://127.0.0.1:8000/api/chat/conversations"
>> 
HTTP/1.1 401 Unauthorized
date: Wed, 14 Jan 2026 17:56:42 GMT
server: uvicorn
content-length: 26
content-type: application/json

{"detail":"Invalid token"}
PS D:\Shoaib Project\nimbus-tasks> @'
>> {"email":"user2@test.com","password":"Pass12345!"}
>> '@ | Set-Content -Encoding utf8 login2.json
>>
PS D:\Shoaib Project\nimbus-tasks> curl.exe -s -X POST "http://127.0.0.1:8000/api/auth/register" -H "Content-Type: application/json" --data-binary "@login2.json"
>>
{"ok":true,"id":17,"email":"user2@test.com"}
PS D:\Shoaib Project\nimbus-tasks> curl.exe -s -X POST "http://127.0.0.1:8000/api/auth/login/json" -H "Content-Type: application/json" --data-binary "@login2.json"
>>
{"access_token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNyIsImlhdCI6MTc2ODQxMzQ0MCwiZXhwIjoxNzY4NDk5ODQwfQ.BqYQGUM5w0EFgdqK04-1F6oeDIViarnFvqP57ikpXwU","token_type":"bearer"}
PS D:\Shoaib Project\nimbus-tasks> curl.exe -i -H "Authorization: Bearer TOKEN_B" "http://127.0.0.1:8000/api/chat/conversations/CONV_ID/messages"
>>
HTTP/1.1 401 Unauthorized
date: Wed, 14 Jan 2026 17:57:30 GMT
server: uvicorn
content-length: 26
content-type: application/json

{"detail":"Invalid token"}
PS D:\Shoaib Project\nimbus-tasks> $TOKEN_A = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNiIsImlhdCI6MTc2ODQxMzM1NSwiZXhwIjoxNzY4NDk5NzU1fQ.ZOHyt2sX15vu-jBri_hMzphbnhQ8xwiUJDjUAGlrZ6U"
>> $TOKEN_B = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNyIsImlhdCI6MTc2ODQxMzQ0MCwiZXhwIjoxNzY4NDk5ODQwfQ.BqYQGUM5w0EFgdqK04-1F6oeDIViarnFvqP57ikpXwU"
>>
PS D:\Shoaib Project\nimbus-tasks> curl.exe -s -X POST "http://127.0.0.1:8000/api/chat" -H "Authorization: Bearer $TOKEN_A" -H "Content-Type: application/json" --data-binary "@chat.json"
>>
{"conversation_id":"393fce58-13f5-48f2-bd3c-c1dc0258651d","response":"ACK: hello","role":"assistant"}
PS D:\Shoaib Project\nimbus-tasks> curl.exe -s -H "Authorization: Bearer $TOKEN_A" "http://127.0.0.1:8000/api/chat/conversations"
>>
[{"id":"393fce58-13f5-48f2-bd3c-c1dc0258651d","created_at":"2026-01-14T17:58:21.450451+00:00","title":null}]
PS D:\Shoaib Project\nimbus-tasks> $CONV_ID = "PASTE_ID_HERE"
>>
PS D:\Shoaib Project\nimbus-tasks> curl.exe -i -H "Authorization: Bearer $TOKEN_A" "http://127.0.0.1:8000/api/chat/conversations/$CONV_ID/messages"
>>
HTTP/1.1 422 Unprocessable Entity
date: Wed, 14 Jan 2026 17:59:42 GMT
server: uvicorn
content-length: 355
content-type: application/json

{"detail":[{"type":"uuid_parsing","loc":["path","conversation_id"],"msg":"Input should be a valid UUID, invalid character: expected an optional prefix of `urn:uuid:` followed by [0-9a-fA-F-], found `P` at 1","input":"PASTE_ID_HERE","ctx":{"error":"invalid character: expected an optional prefix of `urn:uuid:` followed by [0-9a-fA-F-], found `P` at 1"}}]}
PS D:\Shoaib Project\nimbus-tasks> curl.exe -i -H "Authorization: Bearer $TOKEN_B" "http://127.0.0.1:8000/api/chat/conversations/$CONV_ID/messages"
>>
HTTP/1.1 422 Unprocessable Entity
date: Wed, 14 Jan 2026 18:00:04 GMT
server: uvicorn
content-length: 355
content-type: application/json

{"detail":[{"type":"uuid_parsing","loc":["path","conversation_id"],"msg":"Input should be a valid UUID, invalid character: expected an optional prefix of `urn:uuid:` followed by [0-9a-fA-F-], found `P` at 1","input":"PASTE_ID_HERE","ctx":{"error":"invalid character: expected an optional prefix of `urn:uuid:` followed by [0-9a-fA-F-], found `P` at 1"}}]}
PS D:\Shoaib Project\nimbus-tasks> $CONV_ID = "393fce58-13f5-48f2-bd3c-c1dc0258651d"
>>
PS D:\Shoaib Project\nimbus-tasks> curl.exe -i -H "Authorization: Bearer $TOKEN_A" "http://127.0.0.1:8000/api/chat/conversations/$CONV_ID/messages"
>>
HTTP/1.1 200 OK
date: Wed, 14 Jan 2026 18:00:58 GMT
server: uvicorn
content-length: 263
content-type: application/json

[{"id":"c24c2c0d-6e62-4c54-bc1f-ca753c2f0a81","role":"user","content":"hello","created_at":"2026-01-14T17:58:22.884719+00:00"},{"id":"9a4f127b-967a-4333-8de9-120f424cb70a","role":"assistant","content":"ACK: hello","created_at":"2026-01-14T17:58:25.322602+00:00"}]
PS D:\Shoaib Project\nimbus-tasks> curl.exe -i -H "Authorization: Bearer $TOKEN_B" "http://127.0.0.1:8000/api/chat/conversations/$CONV_ID/messages"
>>
HTTP/1.1 404 Not Found
date: Wed, 14 Jan 2026 18:01:16 GMT
server: uvicorn
content-length: 22
content-type: application/json

{"detail":"Not Found"}
PS D:\Shoaib Project\nimbus-tasks>