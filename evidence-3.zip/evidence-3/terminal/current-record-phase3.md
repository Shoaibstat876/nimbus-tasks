PS D:\Shoaib Project\nimbus-tasks> Remove-Variable TOKEN_A,TOKEN_B,CONV_ID -ErrorAction SilentlyContinue
>> 
PS D:\Shoaib Project\nimbus-tasks> @'
>> {"email":"user1@test.com","password":"Pass12345!"}
>> '@ | Set-Content -Encoding utf8 loginA.json
>> 
>> $respA = curl.exe -s -X POST "http://127.0.0.1:8000/api/auth/login/json" `
>>   -H "Content-Type: application/json" --data-binary "@loginA.json"
>> 
>> $respA
>> $TOKEN_A = ($respA | ConvertFrom-Json).access_token
>> $TOKEN_A
>> 
{"access_token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNiIsImlhdCI6MTc2ODQzMDMzMiwiZXhwIjoxNzY4NTE2NzMyfQ.SuPOlkORfPW24W0dvDfXNRb0PcEIUKn1h0i83ce9wbY","token_type":"bearer"}
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNiIsImlhdCI6MTc2ODQzMDMzMiwiZXhwIjoxNzY4NTE2NzMyfQ.SuPOlkORfPW24W0dvDfXNRb0PcEIUKn1h0i83ce9wbY
PS D:\Shoaib Project\nimbus-tasks> @'
>> {"email":"user2@test.com","password":"Pass12345!"}
>> '@ | Set-Content -Encoding utf8 loginB.json
>> 
>> $respB = curl.exe -s -X POST "http://127.0.0.1:8000/api/auth/login/json" `
>>   -H "Content-Type: application/json" --data-binary "@loginB.json"
>> 
>> $respB
>> $TOKEN_B = ($respB | ConvertFrom-Json).access_token
>> $TOKEN_B
>> 
{"access_token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNyIsImlhdCI6MTc2ODQzMDM2OCwiZXhwIjoxNzY4NTE2NzY4fQ.n7y2UnNSUdkned0cPgpd9gHlbRbEwsbIHv-EQwyCytA","token_type":"bearer"}
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNyIsImlhdCI6MTc2ODQzMDM2OCwiZXhwIjoxNzY4NTE2NzY4fQ.n7y2UnNSUdkned0cPgpd9gHlbRbEwsbIHv-EQwyCytA
PS D:\Shoaib Project\nimbus-tasks> curl.exe -i -H "Authorization: Bearer $TOKEN_A" "http://127.0.0.1:8000/api/tasks"
>> curl.exe -i -H "Authorization: Bearer $TOKEN_B" "http://127.0.0.1:8000/api/tasks"
>>
HTTP/1.1 200 OK
date: Wed, 14 Jan 2026 22:40:03 GMT
server: uvicorn
content-length: 2
content-type: application/json

[]HTTP/1.1 200 OK
date: Wed, 14 Jan 2026 22:40:05 GMT
server: uvicorn
content-length: 2
content-type: application/json

[]
PS D:\Shoaib Project\nimbus-tasks> @'
>> {"message":"hello from strict verification"}
>> '@ | Set-Content -Encoding utf8 chat.json
>>
>> $chatResp = curl.exe -s -X POST "http://127.0.0.1:8000/api/chat" `
>>   -H "Authorization: Bearer $TOKEN_A" `
>>   -H "Content-Type: application/json" `
>>   --data-binary "@chat.json"
>>
>> $chatResp
>> $CONV_ID = ($chatResp | ConvertFrom-Json).conversation_id
>> $CONV_ID
>>
{"conversation_id":"365ec1bd-79ae-4104-b657-26f375413466","response":"ACK: hello from strict verification","role":"assistant"}
365ec1bd-79ae-4104-b657-26f375413466
PS D:\Shoaib Project\nimbus-tasks> curl.exe -i -H "Authorization: Bearer $TOKEN_A" `
>> "http://127.0.0.1:8000/api/chat/conversations/365ec1bd-79ae-4104-b657-26f375413466/messages"       
>>
HTTP/1.1 200 OK
date: Wed, 14 Jan 2026 22:41:33 GMT
server: uvicorn
content-length: 313
content-type: application/json

[{"id":"adc1ca70-b191-40b7-a4e1-3ec11e7ec899","role":"user","content":"hello from strict verification","created_at":"2026-01-14T22:40:52.305081+00:00"},{"id":"0002f18a-d21f-4556-b3b9-d7ac1970750e","role":"assistant","content":"ACK: hello from strict verification","created_at":"2026-01-14T22:40:55.550115+00:00"}]
PS D:\Shoaib Project\nimbus-tasks> curl.exe -i -H "Authorization: Bearer $TOKEN_B" `
>> "http://127.0.0.1:8000/api/chat/conversations/365ec1bd-79ae-4104-b657-26f375413466/messages"       
>>
HTTP/1.1 404 Not Found
date: Wed, 14 Jan 2026 22:42:38 GMT
server: uvicorn
content-length: 22
content-type: application/json

{"detail":"Not Found"}
PS D:\Shoaib Project\nimbus-tasks> curl.exe -i -H "Authorization: Bearer $TOKEN_A" `
>> "http://127.0.0.1:8000/api/chat/conversations/365ec1bd-79ae-4104-b657-26f375413466/messages"       
>>
HTTP/1.1 200 OK
date: Wed, 14 Jan 2026 22:44:18 GMT
server: uvicorn
content-length: 313
content-type: application/json

[{"id":"adc1ca70-b191-40b7-a4e1-3ec11e7ec899","role":"user","content":"hello from strict verification","created_at":"2026-01-14T22:40:52.305081+00:00"},{"id":"0002f18a-d21f-4556-b3b9-d7ac1970750e","role":"assistant","content":"ACK: hello from strict verification","created_at":"2026-01-14T22:40:55.550115+00:00"}]

PS D:\Shoaib Project\nimbus-tasks> @'
>> {"title":"DELETE-ME (Phase3 proof)"}
>> '@ | Set-Content -Encoding utf8 task.json
>> 
>> $taskResp = curl.exe -s -X POST "http://127.0.0.1:8000/api/tasks" `
>>   -H "Authorization: Bearer $TOKEN_A" `
>>   -H "Content-Type: application/json" `
>>   --data-binary "@task.json"
>> 
>> $taskResp
>> $TASK_ID = ($taskResp | ConvertFrom-Json).id
>> $TASK_ID
>> 
{"id":24,"user_id":16,"title":"DELETE-ME (Phase3 proof)","is_completed":false,"created_at":"2026-01-14T22:55:13.227018","updated_at":"2026-01-14T22:55:13.227018"}
24
PS D:\Shoaib Project\nimbus-tasks> @"
>> {"conversation_id":"$CONV_ID","message":"delete task $TASK_ID"}
>> "@ | Set-Content -Encoding utf8 del.json
>> 
>> curl.exe -s -X POST "http://127.0.0.1:8000/api/chat" `
>>   -H "Authorization: Bearer $TOKEN_A" `
>>   -H "Content-Type: application/json" `
>>   --data-binary "@del.json"
>> 
{"conversation_id":"365ec1bd-79ae-4104-b657-26f375413466","response":"⚠️ You asked to delete task 24. Reply YES to confirm, or NO to cancel.","role":"assistant"}
PS D:\Shoaib Project\nimbus-tasks> @"
>> {"conversation_id":"$CONV_ID","message":"NO"}
>> "@ | Set-Content -Encoding utf8 no.json
>> 
>> curl.exe -s -X POST "http://127.0.0.1:8000/api/chat" `
>>   -H "Authorization: Bearer $TOKEN_A" `
>>   -H "Content-Type: application/json" `
>>   --data-binary "@no.json"
>>
>> # Verify task still exists
>> curl.exe -i -H "Authorization: Bearer $TOKEN_A" "http://127.0.0.1:8000/api/tasks/$TASK_ID"
>>
{"conversation_id":"365ec1bd-79ae-4104-b657-26f375413466","response":"❎ Cancelled. No changes were made.","role":"assistant"}HTTP/1.1 405 Method Not Allowed
date: Wed, 14 Jan 2026 22:55:51 GMT
server: uvicorn
allow: PUT
content-length: 31
content-type: application/json

{"detail":"Method Not Allowed"}
PS D:\Shoaib Project\nimbus-tasks> # Trigger again
>> curl.exe -s -X POST "http://127.0.0.1:8000/api/chat" `
>>   -H "Authorization: Bearer $TOKEN_A" `
>>   -H "Content-Type: application/json" `
>>   --data-binary "@del.json"
>>
>> # Confirm YES
>> @"
>> {"conversation_id":"$CONV_ID","message":"YES"}
>> "@ | Set-Content -Encoding utf8 yes.json
>>
>> curl.exe -s -X POST "http://127.0.0.1:8000/api/chat" `
>>   -H "Authorization: Bearer $TOKEN_A" `
>>   -H "Content-Type: application/json" `
>>   --data-binary "@yes.json"
>>
>> # Verify task is gone
>> curl.exe -i -H "Authorization: Bearer $TOKEN_A" "http://127.0.0.1:8000/api/tasks/$TASK_ID"
>>
{"conversation_id":"365ec1bd-79ae-4104-b657-26f375413466","response":"⚠️ You asked to delete task 24.  Reply YES to confirm, or NO to cancel.","role":"assistant"}{"conversation_id":"365ec1bd-79ae-4104-b657-26f375413466","response":"✅ Deleted task 24.","role":"assistant"}HTTP/1.1 405 Method Not Allowed
date: Wed, 14 Jan 2026 22:56:22 GMT
server: uvicorn
allow: PUT
content-length: 31
content-type: application/json

{"detail":"Method Not Allowed"}
PS D:\Shoaib Project\nimbus-tasks> 