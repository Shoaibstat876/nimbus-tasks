# 0) Clean variables
Remove-Variable TOKEN_A,TOKEN_B,CONV_ID -ErrorAction SilentlyContinue

# 1) Login User A
@'
{"email":"user1@test.com","password":"Pass12345!"}
'@ | Set-Content -Encoding utf8 loginA.json

$respA = curl.exe -s -X POST "http://127.0.0.1:8000/api/auth/login/json" `
  -H "Content-Type: application/json" --data-binary "@loginA.json"
$TOKEN_A = ($respA | ConvertFrom-Json).access_token

# 2) Login User B
@'
{"email":"user2@test.com","password":"Pass12345!"}
'@ | Set-Content -Encoding utf8 loginB.json

$respB = curl.exe -s -X POST "http://127.0.0.1:8000/api/auth/login/json" `
  -H "Content-Type: application/json" --data-binary "@loginB.json"
$TOKEN_B = ($respB | ConvertFrom-Json).access_token

# 3) Sanity: tasks endpoint works for both
curl.exe -i -H "Authorization: Bearer $TOKEN_A" "http://127.0.0.1:8000/api/tasks"
curl.exe -i -H "Authorization: Bearer $TOKEN_B" "http://127.0.0.1:8000/api/tasks"

# 4) Create new chat convo as User A
@'
{"message":"hello from strict verification"}
'@ | Set-Content -Encoding utf8 chat.json

$chatResp = curl.exe -s -X POST "http://127.0.0.1:8000/api/chat" `
  -H "Authorization: Bearer $TOKEN_A" `
  -H "Content-Type: application/json" `
  --data-binary "@chat.json"

$CONV_ID = ($chatResp | ConvertFrom-Json).conversation_id
$CONV_ID

# 5) Non-owner must get 404
curl.exe -i -H "Authorization: Bearer $TOKEN_B" `
  "http://127.0.0.1:8000/api/chat/conversations/$CONV_ID/messages"

# 6) Owner must get 200
curl.exe -i -H "Authorization: Bearer $TOKEN_A" `
  "http://127.0.0.1:8000/api/chat/conversations/$CONV_ID/messages"
