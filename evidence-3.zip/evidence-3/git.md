                                   cd "D:\Shoaib Project\nimbus-tasks"
>> git add phase2-backend
>> git commit -m "Phase 3: add conversation and message models"
>> git log -1 --oneline
>>
On branch phase3-ai-chatbot
Changes not staged for commit:
  (use "git add <file>..." to update what will be committed)
  (use "git restore <file>..." to discard changes in working directory)
        modified:   phase2-frontend/package-lock.json
        modified:   video-training.md

Untracked files:
  (use "git add <file>..." to include in what will be committed)
        evidence-3/

no changes added to commit (use "git add" and/or "git commit -a")
b6be214 (HEAD -> phase3-ai-chatbot) Phase 3: add chat persistence models and placeholder endpoint     
PS D:\Shoaib Project\nimbus-tasks>