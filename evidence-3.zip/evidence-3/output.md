PS D:\Shoaib Project\nimbus-tasks> $register = @{
>>   email = "demo@nimbus.ai"
>>   password = "DemoPass123!"
>>   full_name = "Nimbus Demo User"
>> } | ConvertTo-Json
>> 
>> Invoke-RestMethod `
>>   -Method Post `
>>   -Uri "http://127.0.0.1:8000/api/auth/register" `
>>   -ContentType "application/json" `
>>   -Body $register
>> 

  ok id email
  -- -- -----
True 14 demo@nimbus.ai


PS D:\Shoaib Project\nimbus-tasks> $auth = Invoke-RestMethod `
>>   -Method Post `
>>   -Uri "http://127.0.0.1:8000/api/auth/login" `
>>   -ContentType "application/x-www-form-urlencoded" `
>>   -Body "username=demo@nimbus.ai&password=DemoPass123!"
>> 
>> $auth
>> 

access_token
------------
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNCIsImlhdCI6MTc2ODM0MDczOCwiZXhwIjoxNzY4NDI3MTM4f...


PS D:\Shoaib Project\nimbus-tasks> $headers = @{
>>   Authorization = "Bearer $($auth.access_token)"
>>   "Content-Type" = "application/json"
>> }
>>
>> $chat = @{ message = "hello" } | ConvertTo-Json
>>
>> Invoke-RestMethod `
>>   -Method Post `
>>   -Uri "http://127.0.0.1:8000/api/chat" `
>>   -Headers $headers `
>>   -Body $chat
>>

conversation_id                      response   role
---------------                      --------   ----
8d777541-7d46-40c6-8440-48c514d40ee7 ACK: hello assistant


PS D:\Shoaib Project\nimbus-tasks>

-------------------------------------------------------------------------------------
PS D:\Shoaib Project\nimbus-tasks> $auth = Invoke-RestMethod `
>>   -Method Post `
>>   -Uri "http://127.0.0.1:8000/api/auth/login" `
>>   -ContentType "application/x-www-form-urlencoded" `
>>   -Body "username=demo@nimbus.ai&password=DemoPass123!"
>> 
PS D:\Shoaib Project\nimbus-tasks> $headers = @{
>>   Authorization = "Bearer $($auth.access_token)"
>>   "Content-Type" = "application/json"
>> }
>> 
PS D:\Shoaib Project\nimbus-tasks> $cid = "8d777541-7d46-40c6-8440-48c514d40ee7"
>> $chat2 = @{ conversation_id = $cid; message = "second message" } | ConvertTo-Json
>> 
>> Invoke-RestMethod `
>>   -Method Post `
>>   -Uri "http://127.0.0.1:8000/api/chat" `
>>   -Headers $headers `
>>   -Body $chat2
>> 

conversation_id                      response            role
---------------                      --------            ----
8d777541-7d46-40c6-8440-48c514d40ee7 ACK: second message assistant


PS D:\Shoaib Project\nimbus-tasks>

---------------------------------------------------------------------------------------------
PS D:\Shoaib Project\nimbus-tasks> $auth = Invoke-RestMethod `
>>   -Method Post `
>>   -Uri "http://127.0.0.1:8000/api/auth/login" `
>>   -ContentType "application/x-www-form-urlencoded" `
>>   -Body "username=demo@nimbus.ai&password=DemoPass123!"
>> 
>> $headers = @{
>>   Authorization = "Bearer $($auth.access_token)"
>>   "Content-Type" = "application/json"
>> }
>> 
>> $chat1 = @{ message = "hello" } | ConvertTo-Json
>> 
>> Invoke-RestMethod `
>>   -Method Post `
>>   -Uri "http://127.0.0.1:8000/api/chat" `
>>   -Headers $headers `
>>   -Body $chat1
>> 

conversation_id                      response   role     
---------------                      --------   ----     
5c006b14-9f2f-436f-9373-0f6d6a150d5a ACK: hello assistant


PS D:\Shoaib Project\nimbus-tasks> $cid = "PASTE_THE_SAME_CONVERSATION_ID"
>> 
>> $chat2 = @{
>>   conversation_id = $cid
>>   message = "second message"
>> } | ConvertTo-Json
>> 
>> Invoke-RestMethod `
>>   -Method Post `
>>   -Uri "http://127.0.0.1:8000/api/chat" `
>>   -Headers $headers `
>>   -Body $chat2
>>
Invoke-RestMethod : {"detail":[{"type":"uuid_parsing","loc":["body","conversation_id"],"msg":"Input 
should be a valid UUID, invalid character: expected an optional prefix of `urn:uuid:` followed by     
[0-9a-fA-F-], found `P` at 1","input":"PASTE_THE_SAME_CONVERSATION_ID","ctx":{"error":"invalid        
character: expected an optional prefix of `urn:uuid:` followed by [0-9a-fA-F-], found `P` at 1"}}]}   
At line:8 char:1
+ Invoke-RestMethod `
+ ~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : InvalidOperation: (System.Net.HttpWebRequest:HttpWebRequest) [Invoke-R  
   estMethod], WebException
    + FullyQualifiedErrorId : WebCmdletWebResponseException,Microsoft.PowerShell.Commands.InvokeRest  
   MethodCommand
PS D:\Shoaib Project\nimbus-tasks> $cid = "8d777541-7d46-40c6-8440-48c514d40ee7"
>>
>> $chat2 = @{
>>   conversation_id = $cid
>>   message = "second message"
>> } | ConvertTo-Json
>>
>> Invoke-RestMethod `
>>   -Method Post `
>>   -Uri "http://127.0.0.1:8000/api/chat" `
>>   -Headers $headers `
>>   -Body $chat2
>>

conversation_id                      response            role
---------------                      --------            ----
8d777541-7d46-40c6-8440-48c514d40ee7 ACK: second message assistant


PS D:\Shoaib Project\nimbus-tasks>