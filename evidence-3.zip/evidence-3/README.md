Phase 3 Evidence

1. Spec-driven planning using Claude Code
2. Authenticated POST /api/chat creates a new conversation
3. Same conversation_id reused across requests proving DB persistence
