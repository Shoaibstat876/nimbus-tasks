🎬 OPTION A — Final 90-Second Demo Script (Phase 3)

(Read or follow this exactly. No extra steps.)

0–10s — Context

“This is Nimbus Tasks, Hackathon Phase 3.
Goal: a stateless, authenticated chat backend with DB-persisted memory, built spec-first.”

10–25s — Backend up

Show terminal:

uvicorn app.main:app --reload --port 8000 --env-file .env


Say:

“Backend is running. Phase-2 endpoints remain intact.”

25–35s — Health check

Invoke-RestMethod http://127.0.0.1:8000/api/health


“Health is OK.”

35–55s — Auth + new conversation

Register / login (already scripted)

Show first chat:

POST /api/chat  →  message: "hello"


“A new conversation is created and persisted. Response is returned.”

55–75s — Stateless continuation

POST /api/chat
conversation_id = <same id>
message = "second message"


“Same conversation continues using the ID. No server memory—DB only.”

75–90s — Guarantees

“JWT enforced, owner-only access returns 404, and all messages persist in the database.
Phase 3 objective complete.”

STOP.