# Phase 3 — Step 4 Evidence: Confirmation on Destructive Actions (Delete)

## Requirement
Destructive actions (e.g., deleting a task) must **require explicit user confirmation**.
The system must:
- NOT delete immediately
- Ask for confirmation (YES / NO)
- Proceed only after explicit confirmation

---

## Setup
- Authenticated user: **User A**
- Existing conversation owned by User A
- One task created for deletion testing

---

## Proof

### 1) Create a task (baseline)
```powershell
@'
{"title":"DELETE-ME (Phase 3 confirmation proof)"}
'@ | Set-Content -Encoding utf8 task.json

curl.exe -s -X POST "http://127.0.0.1:8000/api/tasks" `
  -H "Authorization: Bearer $TOKEN_A" `
  -H "Content-Type: application/json" `
  --data-binary "@task.json"
