# Phase 3 — Step 3 Evidence: Owner-only chat history (404)

## Requirement
Chat history must be **owner-only**. If a different authenticated user tries to access a conversation they do not own, the API must respond with **404 Not Found** (privacy-preserving behavior).

## Setup
- Two authenticated users: User A (owner) and User B (non-owner)
- Conversation created by User A
- Conversation ID: `393fce58-13f5-48f2-bd3c-c1dc0258651d`

## Proof

### 1) Owner can read messages (expected: 200)
```powershell
curl.exe -i -H "Authorization: Bearer $TOKEN_A" "http://127.0.0.1:8000/api/chat/conversations/393fce58-13f5-48f2-bd3c-c1dc0258651d/messages"

### Non-owner cannot read the same conversation (expected: 404)
``` powershell 
curl.exe -i -H "Authorization: Bearer $TOKEN_B" "http://127.0.0.1:8000/api/chat/conversations/393fce58-13f5-48f2-bd3c-c1dc0258651d/messages"
