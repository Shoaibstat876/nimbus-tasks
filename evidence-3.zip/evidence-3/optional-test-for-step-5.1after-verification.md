PS D:\Shoaib Project\nimbus-tasks> @'
>> {"email":"user2@test.com","password":"Pass12345!"}
>> '@ | Set-Content -Encoding utf8 registerB.json
>> 
>> curl.exe -s -X POST "http://127.0.0.1:8000/api/auth/register" `
>>   -H "Content-Type: application/json" `
>>   --data-binary "@registerB.json"
>> 
{"detail":"Email already registered"}
PS D:\Shoaib Project\nimbus-tasks> @'
>> {"email":"user2@test.com","password":"Pass12345!"}
>> '@ | Set-Content -Encoding utf8 loginB.json
>> 
>> $respB = curl.exe -s -X POST "http://127.0.0.1:8000/api/auth/login/json" `
>>   -H "Content-Type: application/json" `
>>   --data-binary "@loginB.json"
>> 
>> $TOKEN_B = ($respB | ConvertFrom-Json).access_token
>> $TOKEN_B
>> 
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxNyIsImlhdCI6MTc2ODUyMTQyOCwiZXhwIjoxNzY4NjA3ODI4fQ._YLBKFrOSeC4MoooOxjvvFenVH9mJRQIu4ylbu2ZlJQ
PS D:\Shoaib Project\nimbus-tasks> curl.exe -i -X GET "http://127.0.0.1:8000/api/chat/history/$CONV_ID" `
>>   -H "Authorization: Bearer $TOKEN_B"
>> 
HTTP/1.1 404 Not Found
date: Thu, 15 Jan 2026 23:57:16 GMT
server: uvicorn
content-length: 22
content-type: application/json

{"detail":"Not Found"}
PS D:\Shoaib Project\nimbus-tasks> 